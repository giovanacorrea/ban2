# models/__init__.py
from .db import db
from .Pessoa import Pessoa
from .Hospedes import Hospedes

__all__ = ['db', 'Pessoa', 'Hospede']
